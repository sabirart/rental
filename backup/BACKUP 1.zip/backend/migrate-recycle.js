const { run, query } = require('./config/database');

async function migrate() {
    console.log('Adding recycle_bin table...');
    
    try {
        await run(`
            CREATE TABLE IF NOT EXISTS recycle_bin (
                id TEXT PRIMARY KEY,
                original_id TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('tenant', 'property')),
                data TEXT NOT NULL,
                deleted_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // Add indexes
        await run('CREATE INDEX IF NOT EXISTS idx_recycle_type ON recycle_bin(type)');
        await run('CREATE INDEX IF NOT EXISTS idx_recycle_deleted_at ON recycle_bin(deleted_at)');
        
        console.log('Recycle bin table created successfully');
    } catch (error) {
        console.error('Migration failed:', error.message);
    }
}

migrate().then(() => process.exit(0));