// backend/add-test-users.js

const { run, query } = require('./config/database');

async function addTestUsers() {
    console.log('🚀 Adding test users...\n');

    const testUsers = [
        {
            name: 'Ahmed Khan',
            father_name: 'Mohammad Khan',
            cnic: '12345-1234567-1',
            location: 'Karachi, Sindh',
            description: 'Software Engineer, lives alone',
            status: 'active'
        },
        {
            name: 'Fatima Ali',
            father_name: 'Ali Ahmed',
            cnic: '12345-1234567-2',
            location: 'Lahore, Punjab',
            description: 'Teacher, family of 3',
            status: 'active'
        },
        {
            name: 'Mohammad Raza',
            father_name: 'Hussain Raza',
            cnic: '12345-1234567-3',
            location: 'Islamabad, Capital',
            description: 'Government employee',
            status: 'active'
        },
        {
            name: 'Sara Malik',
            father_name: 'Tariq Malik',
            cnic: '12345-1234567-4',
            location: 'Rawalpindi, Punjab',
            description: 'Doctor, works at local hospital',
            status: 'active'
        },
        {
            name: 'Usman Butt',
            father_name: 'Akhtar Butt',
            cnic: '12345-1234567-5',
            location: 'Faisalabad, Punjab',
            description: 'Business owner',
            status: 'active'
        },
        {
            name: 'Ayesha Noor',
            father_name: 'Noor Ahmed',
            cnic: '12345-1234567-6',
            location: 'Peshawar, KPK',
            description: 'University student',
            status: 'active'
        },
        {
            name: 'Hira Khan',
            father_name: 'Javed Khan',
            cnic: '12345-1234567-8',
            location: 'Multan, Punjab',
            description: 'Graphic designer, remote worker',
            status: 'active'
        },
        {
            name: 'Zain Abbas',
            father_name: 'Abbas Shah',
            cnic: '12345-1234567-9',
            location: 'Hyderabad, Sindh',
            description: 'Accountant',
            status: 'active'
        },
        {
            name: 'Maryam Akhtar',
            father_name: 'Akhtar Ali',
            cnic: '12345-1234567-0',
            location: 'Gujranwala, Punjab',
            description: 'Marketing professional',
            status: 'active'
        }
    ];

    let successCount = 0;
    let failCount = 0;

    try {
        // Get first property to assign rooms
        const properties = await query('SELECT * FROM properties');
        let propertyId = null;
        let totalRooms = 0;
        
        if (properties && properties.length > 0) {
            propertyId = properties[0].id;
            totalRooms = properties[0].total_rooms || 5;
            console.log(`📋 Found property: ${properties[0].name} (${totalRooms} rooms)\n`);
        } else {
            console.log('⚠️  No properties found. Tenants will be added without room assignment.\n');
        }

        // Insert each user
        for (let i = 0; i < testUsers.length; i++) {
            const user = testUsers[i];
            const id = 'test_' + Date.now() + '_' + i;
            const roomNumber = propertyId ? (i % totalRooms) + 1 : null;
            
            try {
                // Check if CNIC already exists
                const existing = await query('SELECT * FROM tenants WHERE cnic = ?', [user.cnic]);
                if (existing && existing.length > 0) {
                    console.log(`⚠️  Skipped: ${user.name} (CNIC already exists)`);
                    failCount++;
                    continue;
                }

                // Insert without profile_pic column
                await run(
                    `INSERT INTO tenants (id, name, father_name, cnic, location, description, status, property_id, room_number)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [id, user.name, user.father_name, user.cnic, user.location, 
                     user.description, user.status, propertyId, roomNumber]
                );
                console.log(`✅ Added: ${user.name} (CNIC: ${user.cnic})${roomNumber ? ` - Room ${roomNumber}` : ''}`);
                successCount++;
            } catch (err) {
                console.log(`❌ Error adding ${user.name}:`, err.message);
                failCount++;
            }
        }

        console.log(`\n✅ Test users added successfully!`);
        console.log(`📊 Added: ${successCount}, Skipped: ${failCount}`);

        // Show summary
        const result = await query('SELECT COUNT(*) as count FROM tenants');
        console.log(`📈 Total tenants in database: ${result[0].count}`);

        // Show recent users
        const recent = await query('SELECT name, cnic, location, status FROM tenants ORDER BY created_at DESC LIMIT 5');
        console.log('\n📋 Recent tenants:');
        recent.forEach(user => {
            console.log(`   - ${user.name} (${user.cnic}) - ${user.location}`);
        });

    } catch (error) {
        console.error('❌ Error:', error.message);
    }
}

// Run the function
addTestUsers().then(() => {
    process.exit(0);
}).catch((err) => {
    console.error(err);
    process.exit(1);
});