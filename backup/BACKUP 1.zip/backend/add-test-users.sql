-- backend/add-test-users.sql

-- Insert test users with sample data
INSERT OR IGNORE INTO tenants (id, name, father_name, ID, location, description, status, created_at) 
VALUES 
('test1_' || strftime('%s','now'), 'Ahmed Khan', 'Mohammad Khan', '12345-1234567-1', 'Karachi, Sindh', 'Software Engineer', 'active', datetime('now')),
('test2_' || strftime('%s','now'), 'Fatima Ali', 'Ali Ahmed', '12345-1234567-2', 'Lahore, Punjab', 'Teacher', 'active', datetime('now')),
('test3_' || strftime('%s','now'), 'Mohammad Raza', 'Hussain Raza', '12345-1234567-3', 'Islamabad, Capital', 'Government employee', 'active', datetime('now')),
('test4_' || strftime('%s','now'), 'Sara Malik', 'Tariq Malik', '12345-1234567-4', 'Rawalpindi, Punjab', 'Doctor', 'active', datetime('now')),
('test5_' || strftime('%s','now'), 'Usman Butt', 'Akhtar Butt', '12345-1234567-5', 'Faisalabad, Punjab', 'Business owner', 'active', datetime('now')),
('test6_' || strftime('%s','now'), 'Ayesha Noor', 'Noor Ahmed', '12345-1234567-6', 'Peshawar, KPK', 'University student', 'active', datetime('now')),
('test7_' || strftime('%s','now'), 'Bilal Hassan', 'Hassan Ali', '12345-1234567-7', 'Quetta, Balochistan', 'Engineer', 'active', datetime('now')),
('test8_' || strftime('%s','now'), 'Hira Khan', 'Javed Khan', '12345-1234567-8', 'Multan, Punjab', 'Graphic designer', 'active', datetime('now')),
('test9_' || strftime('%s','now'), 'Zain Abbas', 'Abbas Shah', '12345-1234567-9', 'Hyderabad, Sindh', 'Accountant', 'active', datetime('now')),
('test10_' || strftime('%s','now'), 'Maryam Akhtar', 'Akhtar Ali', '12345-1234567-0', 'Gujranwala, Punjab', 'Marketing professional', 'active', datetime('now'));

-- Show results
SELECT 'Added ' || changes() || ' new tenants' as status;
SELECT * FROM tenants ORDER BY created_at DESC LIMIT 10;