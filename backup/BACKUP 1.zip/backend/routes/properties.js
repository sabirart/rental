const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/propertyController');
const { validateProperty, validate } = require('../middleware/validation');

router.get('/', propertyController.getAll);
router.get('/:id', propertyController.getById);
router.get('/:id/rooms', propertyController.getRooms);
router.post('/', validateProperty, validate, propertyController.create);
router.put('/:id', validateProperty, validate, propertyController.update);
router.delete('/:id', propertyController.delete);
router.put('/:id/rooms/:roomNumber', propertyController.updateRoom);
router.post('/:id/rooms', propertyController.addRoom);
router.delete('/:id/rooms/:roomNumber', propertyController.removeRoom);
router.delete('/clear', propertyController.clearAll);

module.exports = router;