// js/api.js (FIXED - Added environment config, error handling, retry logic)

const API = {
    // FIXED: Environment-aware base URL
    get baseURL() {
        // Check for environment variable first
        if (window.API_URL) {
            return window.API_URL;
        }
        // Check localStorage for custom URL
        const storedURL = localStorage.getItem('api_url');
        if (storedURL) {
            return storedURL;
        }
        // Default fallback
        return 'http://localhost:5000/api';
    },
    
    // FIXED: Set custom API URL
    setBaseURL(url) {
        localStorage.setItem('api_url', url);
        window.API_URL = url;
    },
    
    // FIXED: Helper for making API requests with retry logic
    async request(endpoint, method = 'GET', data = null, retries = 2) {
        const url = `${this.baseURL}${endpoint}`;
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
            }
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        let lastError = null;
        
        // Retry logic for network errors
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                const response = await fetch(url, options);
                const result = await response.json();
                
                if (!response.ok) {
                    throw new Error(result.error || result.message || 'API request failed');
                }
                
                return result;
            } catch (error) {
                lastError = error;
                console.error(`API Error (attempt ${attempt + 1}/${retries + 1}):`, error.message);
                
                // Only retry on network errors, not on 4xx/5xx responses
                if (error.message.includes('API request failed') && attempt < retries) {
                    // Wait before retry (exponential backoff)
                    await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
                    continue;
                }
                
                // Don't retry on validation errors
                if (error.message.includes('validation') || error.message.includes('required')) {
                    break;
                }
            }
        }
        
        throw lastError || new Error('API request failed after multiple attempts');
    },

    // FIXED: Check API health
    async healthCheck() {
        try {
            const response = await fetch(`${this.baseURL}/health`);
            return response.ok;
        } catch (error) {
            return false;
        }
    },

    // Clear all data endpoints
    async deleteAllTenants() {
        return this.request('/tenants/clear', 'DELETE');
    },

    async deleteAllProperties() {
        return this.request('/properties/clear', 'DELETE');
    },

    async deleteAllPayments() {
        return this.request('/payments/clear', 'DELETE');
    },
    
    // Tenant endpoints
    async getTenants() {
        return this.request('/tenants');
    },
    
    async getTenant(id) {
        return this.request(`/tenants/${id}`);
    },
    
    async createTenant(data) {
        return this.request('/tenants', 'POST', data);
    },
    
    async updateTenant(id, data) {
        return this.request(`/tenants/${id}`, 'PUT', data);
    },
    
    async deleteTenant(id) {
        return this.request(`/tenants/${id}`, 'DELETE');
    },
    
    async getTenantsByProperty(propertyId) {
        return this.request(`/tenants/property/${propertyId}`);
    },
    
    // Property endpoints
    async getProperties() {
        return this.request('/properties');
    },
    
    async getProperty(id) {
        return this.request(`/properties/${id}`);
    },
    
    async createProperty(data) {
        // If roomRents is provided, we'll handle it differently
        if (data.roomRents) {
            const roomRents = data.roomRents;
            delete data.roomRents; // Remove from main data
            
            // Create property first
            const response = await this.request('/properties', 'POST', data);
            
            // Then update each room with individual rent
            if (response.data && response.data.id) {
                const propertyId = response.data.id;
                for (const [roomNum, rent] of Object.entries(roomRents)) {
                    await this.updateRoom(propertyId, parseInt(roomNum), {
                        rentAmount: rent,
                        roomName: `Room ${roomNum}`
                    });
                }
            }
            
            // Re-fetch property with updated rooms
            return this.getProperty(response.data.id);
        }
        
        return this.request('/properties', 'POST', data);
    },

    async updateProperty(id, data) {
        return this.request(`/properties/${id}`, 'PUT', data);
    },
    
    async deleteProperty(id) {
        return this.request(`/properties/${id}`, 'DELETE');
    },
    
    async getPropertyRooms(id) {
        return this.request(`/properties/${id}/rooms`);
    },
    
    async updateRoom(propertyId, roomNumber, data) {
        return this.request(`/properties/${propertyId}/rooms/${roomNumber}`, 'PUT', data);
    },
    
    async addRoom(propertyId, data) {
        return this.request(`/properties/${propertyId}/rooms`, 'POST', data);
    },
    
    // Payment endpoints
    async getPayments(filters = {}) {
        const queryString = new URLSearchParams(filters).toString();
        const endpoint = queryString ? `/payments?${queryString}` : '/payments';
        return this.request(endpoint);
    },
    
    async getPayment(id) {
        return this.request(`/payments/${id}`);
    },
    
    async createPayment(data) {
        return this.request('/payments', 'POST', data);
    },
    
    async updatePayment(id, data) {
        return this.request(`/payments/${id}`, 'PUT', data);
    },
    
    async deletePayment(id) {
        return this.request(`/payments/${id}`, 'DELETE');
    },
    
    async getPaymentsByTenant(tenantId) {
        return this.request(`/payments/tenant/${tenantId}`);
    },
    
    async getDashboardStats() {
        return this.request('/payments/dashboard-stats');
    },
    
    async getMonthlySummary(year, month) {
        return this.request(`/payments/monthly-summary?year=${year}&month=${month}`);
    },

    // ===== RECYCLE BIN ENDPOINTS =====
    async getRecycleItems(type = null) {
        const endpoint = type ? `/recycle?type=${type}` : '/recycle';
        return this.request(endpoint);
    },

    async getRecycleCount() {
        return this.request('/recycle/count');
    },

    async recoverRecycleItem(id) {
        return this.request(`/recycle/recover/${id}`, 'POST');
    },

    async deleteRecycleItem(id) {
        return this.request(`/recycle/${id}`, 'DELETE');
    },

    async clearRecycleBin(type = null) {
        const endpoint = type ? `/recycle/clear/all?type=${type}` : '/recycle/clear/all';
        return this.request(endpoint, 'DELETE');
    },

    async cleanRecycleBin(days = 15) {
        return this.request(`/recycle/clear/old?days=${days}`, 'DELETE');
    },

    async removeRoom(propertyId, roomNumber) {
    return this.request(`/properties/${propertyId}/rooms/${roomNumber}`, 'DELETE');
},
};

// FIXED: Make API globally available
window.API = API;